// ref_gemvt.cpp
// 
// This file is intentionally left empty because the gemv function is a template
// and must be fully defined in the header file (ref_gemvt.hpp).
// Templates cannot be separately compiled like regular functions.