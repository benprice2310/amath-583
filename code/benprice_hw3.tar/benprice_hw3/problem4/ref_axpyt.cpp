// ref_axpyt.cpp
// 
// This file is intentionally left empty because the axpy function is a template
// and must be fully defined in the header file (ref_axpyt.hpp).
// Templates cannot be separately compiled like regular functions.