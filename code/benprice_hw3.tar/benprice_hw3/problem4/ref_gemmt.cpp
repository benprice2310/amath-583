// ref_gemmt.cpp
// 
// This file is intentionally left empty because the gemm function is a template
// and must be fully defined in the header file (ref_gemmt.hpp).
// Templates cannot be separately compiled like regular functions.