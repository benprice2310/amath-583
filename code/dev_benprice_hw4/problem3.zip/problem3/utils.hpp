// utils.hpp
#ifndef AM583_SP25_HW4_P3_UTILS_HPP
#define AM583_SP25_HW4_P3_UTILS_HPP

#endif // utils.hpp